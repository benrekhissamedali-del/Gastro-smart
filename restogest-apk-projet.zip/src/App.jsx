import React, { useState, useMemo, useEffect } from 'react';
import {
  LayoutDashboard, ShoppingCart, Package, ChefHat, BarChart3, Users,
  Settings, LogOut, TrendingUp, TrendingDown, AlertTriangle, Search,
  Plus, Minus, X, CreditCard, Banknote, Printer, Download, Upload,
  Bell, Moon, Sun, ChevronRight, Edit2, Trash2, Eye, EyeOff, Check,
  Lock, Mail, Smartphone, Crown, Zap, Star, ArrowUpRight, ArrowDownRight,
  Filter, Calendar, Clock, DollarSign, Percent, AlertCircle, Sparkles,
  FileSpreadsheet, ChevronDown, MoreVertical, Menu, Flame, Award, Target
} from 'lucide-react';
import {
  LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  RadialBarChart, RadialBar
} from 'recharts';

// ============ DONNÉES DE TEST TUNISIENNES ============
const INITIAL_STOCK = [
  { id: 1, name: 'Semoule moyenne', unit: 'kg', quantity: 45, minStock: 20, pricePerUnit: 2.5, supplier: 'Moulin Sidi Bou Said', lastUpdate: '2026-04-15' },
  { id: 2, name: 'Viande agneau', unit: 'kg', quantity: 8, minStock: 15, pricePerUnit: 42, supplier: 'Boucherie El Menzah', lastUpdate: '2026-04-16' },
  { id: 3, name: 'Tomate fraîche', unit: 'kg', quantity: 25, minStock: 10, pricePerUnit: 3.2, supplier: 'Marché Central', lastUpdate: '2026-04-16' },
  { id: 4, name: 'Huile d\'olive', unit: 'L', quantity: 12, minStock: 8, pricePerUnit: 18, supplier: 'Domaine Zitouna', lastUpdate: '2026-04-14' },
  { id: 5, name: 'Oignon', unit: 'kg', quantity: 30, minStock: 10, pricePerUnit: 1.8, supplier: 'Marché Central', lastUpdate: '2026-04-16' },
  { id: 6, name: 'Harissa', unit: 'kg', quantity: 3.5, minStock: 2, pricePerUnit: 12, supplier: 'Le Phare', lastUpdate: '2026-04-13' },
  { id: 7, name: 'Poulet entier', unit: 'kg', quantity: 18, minStock: 10, pricePerUnit: 14, supplier: 'Volailles Medina', lastUpdate: '2026-04-16' },
  { id: 8, name: 'Pomme de terre', unit: 'kg', quantity: 40, minStock: 15, pricePerUnit: 1.5, supplier: 'Marché Central', lastUpdate: '2026-04-15' },
  { id: 9, name: 'Œufs', unit: 'pcs', quantity: 120, minStock: 60, pricePerUnit: 0.35, supplier: 'Ferme El Ouerda', lastUpdate: '2026-04-16' },
  { id: 10, name: 'Thon en boîte', unit: 'pcs', quantity: 48, minStock: 24, pricePerUnit: 4.5, supplier: 'Sidi Daoud', lastUpdate: '2026-04-12' },
  { id: 11, name: 'Feuille de brik', unit: 'pcs', quantity: 85, minStock: 50, pricePerUnit: 0.4, supplier: 'Pâtisserie Masmoudi', lastUpdate: '2026-04-15' },
  { id: 12, name: 'Menthe fraîche', unit: 'botte', quantity: 15, minStock: 8, pricePerUnit: 1.2, supplier: 'Marché Central', lastUpdate: '2026-04-16' },
  { id: 13, name: 'Thé vert', unit: 'kg', quantity: 2.8, minStock: 1.5, pricePerUnit: 35, supplier: 'Import Maghreb', lastUpdate: '2026-04-10' },
  { id: 14, name: 'Sucre', unit: 'kg', quantity: 22, minStock: 10, pricePerUnit: 2, supplier: 'STSM', lastUpdate: '2026-04-14' },
  { id: 15, name: 'Pignons de pin', unit: 'kg', quantity: 1.2, minStock: 2, pricePerUnit: 85, supplier: 'Import Maghreb', lastUpdate: '2026-04-11' },
];

const INITIAL_RECIPES = [
  {
    id: 1, name: 'Couscous Agneau', category: 'Plat principal', sellPrice: 28,
    ingredients: [
      { stockId: 1, quantity: 0.2 }, // Semoule
      { stockId: 2, quantity: 0.25 }, // Agneau
      { stockId: 3, quantity: 0.15 }, // Tomate
      { stockId: 5, quantity: 0.1 }, // Oignon
      { stockId: 4, quantity: 0.03 }, // Huile
      { stockId: 6, quantity: 0.02 }, // Harissa
    ],
    image: '🍲'
  },
  {
    id: 2, name: 'Brik à l\'œuf', category: 'Entrée', sellPrice: 6,
    ingredients: [
      { stockId: 11, quantity: 1 }, // Feuille brik
      { stockId: 9, quantity: 1 }, // Œuf
      { stockId: 10, quantity: 0.3 }, // Thon
      { stockId: 12, quantity: 0.1 }, // Menthe
      { stockId: 4, quantity: 0.02 }, // Huile
    ],
    image: '🥟'
  },
  {
    id: 3, name: 'Lablebi', category: 'Plat principal', sellPrice: 8,
    ingredients: [
      { stockId: 4, quantity: 0.04 }, // Huile
      { stockId: 6, quantity: 0.03 }, // Harissa
      { stockId: 9, quantity: 1 }, // Œuf
      { stockId: 10, quantity: 0.2 }, // Thon
    ],
    image: '🍜'
  },
  {
    id: 4, name: 'Poulet Rôti', category: 'Plat principal', sellPrice: 22,
    ingredients: [
      { stockId: 7, quantity: 0.4 }, // Poulet
      { stockId: 8, quantity: 0.3 }, // Pomme de terre
      { stockId: 5, quantity: 0.1 }, // Oignon
      { stockId: 4, quantity: 0.04 }, // Huile
    ],
    image: '🍗'
  },
  {
    id: 5, name: 'Thé à la menthe', category: 'Boisson', sellPrice: 3,
    ingredients: [
      { stockId: 13, quantity: 0.01 }, // Thé
      { stockId: 12, quantity: 0.05 }, // Menthe
      { stockId: 14, quantity: 0.03 }, // Sucre
      { stockId: 15, quantity: 0.005 }, // Pignons
    ],
    image: '🍵'
  },
  {
    id: 6, name: 'Salade Tunisienne', category: 'Entrée', sellPrice: 7,
    ingredients: [
      { stockId: 3, quantity: 0.2 }, // Tomate
      { stockId: 5, quantity: 0.08 }, // Oignon
      { stockId: 4, quantity: 0.03 }, // Huile
      { stockId: 10, quantity: 0.15 }, // Thon
      { stockId: 9, quantity: 1 }, // Œuf
    ],
    image: '🥗'
  },
  {
    id: 7, name: 'Mlewi', category: 'Entrée', sellPrice: 5,
    ingredients: [
      { stockId: 1, quantity: 0.15 }, // Semoule
      { stockId: 4, quantity: 0.025 }, // Huile
    ],
    image: '🫓'
  },
  {
    id: 8, name: 'Chorba Frik', category: 'Entrée', sellPrice: 6,
    ingredients: [
      { stockId: 2, quantity: 0.08 }, // Agneau
      { stockId: 3, quantity: 0.1 }, // Tomate
      { stockId: 5, quantity: 0.06 }, // Oignon
      { stockId: 4, quantity: 0.02 }, // Huile
    ],
    image: '🍲'
  },
];

// Ventes historiques (14 derniers jours)
const generateSalesHistory = () => {
  const data = [];
  const today = new Date('2026-04-16');
  for (let i = 13; i >= 0; i--) {
    const date = new Date(today);
    date.setDate(date.getDate() - i);
    const isWeekend = date.getDay() === 0 || date.getDay() === 6;
    const base = isWeekend ? 2800 : 1800;
    const variance = Math.random() * 800 - 400;
    data.push({
      date: date.toISOString().split('T')[0],
      day: date.toLocaleDateString('fr-FR', { weekday: 'short' }),
      dayShort: date.getDate() + '/' + (date.getMonth() + 1),
      ca: Math.round(base + variance),
      orders: Math.round((base + variance) / 22),
      foodCost: Math.round(((base + variance) * (0.28 + Math.random() * 0.08)) * 100) / 100,
    });
  }
  return data;
};

const SALES_HISTORY = generateSalesHistory();

const TOP_PRODUCTS = [
  { name: 'Couscous Agneau', sold: 142, revenue: 3976, trend: 12 },
  { name: 'Poulet Rôti', sold: 98, revenue: 2156, trend: 8 },
  { name: 'Brik à l\'œuf', sold: 186, revenue: 1116, trend: 15 },
  { name: 'Thé à la menthe', sold: 245, revenue: 735, trend: 22 },
  { name: 'Lablebi', sold: 76, revenue: 608, trend: -5 },
];

const USERS = [
  { id: 1, name: 'Mohamed Ben Ali', role: 'Admin', email: 'mohamed@darelhout.tn', lastLogin: '2026-04-16 09:15', status: 'actif' },
  { id: 2, name: 'Sonia Trabelsi', role: 'Manager', email: 'sonia@darelhout.tn', lastLogin: '2026-04-16 08:30', status: 'actif' },
  { id: 3, name: 'Karim Jebali', role: 'Caissier', email: 'karim@darelhout.tn', lastLogin: '2026-04-16 11:45', status: 'actif' },
  { id: 4, name: 'Leila Mansouri', role: 'Caissier', email: 'leila@darelhout.tn', lastLogin: '2026-04-15 20:10', status: 'actif' },
  { id: 5, name: 'Ahmed Gharbi', role: 'Serveur', email: 'ahmed@darelhout.tn', lastLogin: '2026-04-14 19:20', status: 'inactif' },
];

// ============ UTILITAIRES ============
const formatTND = (n) => new Intl.NumberFormat('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 3 }).format(n) + ' TND';
const formatNum = (n) => new Intl.NumberFormat('fr-FR').format(n);

const calculateRecipeCost = (recipe, stock) => {
  return recipe.ingredients.reduce((total, ing) => {
    const item = stock.find(s => s.id === ing.stockId);
    return total + (item ? item.pricePerUnit * ing.quantity : 0);
  }, 0);
};

// ============ COMPOSANT LOGIN ============
const LoginScreen = ({ onLogin }) => {
  const [email, setEmail] = useState('mohamed@darelhout.tn');
  const [password, setPassword] = useState('demo2026');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = () => {
    setLoading(true);
    setTimeout(() => { onLogin(); setLoading(false); }, 600);
  };

  return (
    <div className="min-h-screen w-full flex bg-neutral-950 text-white overflow-hidden">
      {/* Panneau gauche - branding */}
      <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden">
        <div className="absolute inset-0" style={{
          background: 'radial-gradient(circle at 30% 20%, rgba(212, 165, 116, 0.15) 0%, transparent 50%), radial-gradient(circle at 70% 80%, rgba(201, 169, 97, 0.1) 0%, transparent 50%), #0a0a0a'
        }}/>
        <div className="absolute inset-0 opacity-[0.03]" style={{
          backgroundImage: 'repeating-linear-gradient(0deg, #d4a574 0px, #d4a574 1px, transparent 1px, transparent 40px), repeating-linear-gradient(90deg, #d4a574 0px, #d4a574 1px, transparent 1px, transparent 40px)'
        }}/>
        <div className="relative z-10 flex flex-col justify-between p-12 w-full">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-lg flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #d4a574 0%, #c9a961 100%)' }}>
              <ChefHat className="w-6 h-6 text-neutral-950" strokeWidth={2.5}/>
            </div>
            <div>
              <div className="font-serif text-xl tracking-wide">RestoGest</div>
              <div className="text-xs text-neutral-500 tracking-[0.2em] uppercase">Premium Suite</div>
            </div>
          </div>

          <div>
            <div className="text-[#d4a574] text-sm tracking-[0.3em] uppercase mb-4">Nouveauté 2026</div>
            <h1 className="font-serif text-5xl xl:text-6xl leading-tight mb-6">
              La gestion de restaurant <em className="text-[#d4a574]">réinventée</em>
            </h1>
            <p className="text-neutral-400 text-lg max-w-md leading-relaxed">
              Pensé pour les restaurateurs tunisiens et nord-africains. POS, stock, food cost et analytics — tout dans une seule app.
            </p>
          </div>

          <div className="flex items-center gap-8 text-neutral-500 text-sm">
            <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-green-400 animate-pulse"/>2,400+ restos actifs</div>
            <div>🇹🇳 Made in Tunisia</div>
          </div>
        </div>
      </div>

      {/* Panneau droit - login */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-6 sm:p-12 bg-neutral-50 text-neutral-900">
        <div className="w-full max-w-md">
          <div className="lg:hidden flex items-center gap-3 mb-10">
            <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #d4a574 0%, #c9a961 100%)' }}>
              <ChefHat className="w-5 h-5 text-white" strokeWidth={2.5}/>
            </div>
            <div className="font-serif text-lg">RestoGest</div>
          </div>

          <div className="mb-10">
            <div className="text-xs tracking-[0.3em] uppercase text-[#c9a961] mb-3">Connexion</div>
            <h2 className="font-serif text-4xl mb-3">Bon retour.</h2>
            <p className="text-neutral-500">Accédez à votre tableau de bord Dar El Hout.</p>
          </div>

          <div className="space-y-5">
            <div>
              <label className="block text-xs uppercase tracking-wider text-neutral-500 mb-2">Email</label>
              <div className="relative">
                <Mail className="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 text-neutral-400"/>
                <input type="email" value={email} onChange={e=>setEmail(e.target.value)}
                  className="w-full bg-white border border-neutral-200 rounded-lg py-3.5 pl-11 pr-4 focus:border-[#c9a961] focus:ring-2 focus:ring-[#c9a961]/20 outline-none transition"
                  placeholder="vous@restaurant.tn"/>
              </div>
            </div>
            <div>
              <label className="block text-xs uppercase tracking-wider text-neutral-500 mb-2">Mot de passe</label>
              <div className="relative">
                <Lock className="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 text-neutral-400"/>
                <input type={showPassword?'text':'password'} value={password} onChange={e=>setPassword(e.target.value)}
                  className="w-full bg-white border border-neutral-200 rounded-lg py-3.5 pl-11 pr-11 focus:border-[#c9a961] focus:ring-2 focus:ring-[#c9a961]/20 outline-none transition"/>
                <button onClick={()=>setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-700">
                  {showPassword ? <EyeOff className="w-4 h-4"/> : <Eye className="w-4 h-4"/>}
                </button>
              </div>
            </div>
            <div className="flex items-center justify-between text-sm">
              <label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" defaultChecked className="w-4 h-4 rounded accent-[#c9a961]"/><span className="text-neutral-600">Se souvenir</span></label>
              <button className="text-[#c9a961] hover:underline">Mot de passe oublié ?</button>
            </div>
            <button onClick={handleSubmit} disabled={loading}
              className="w-full py-3.5 rounded-lg font-medium transition-all text-white flex items-center justify-center gap-2 disabled:opacity-60"
              style={{ background: 'linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%)' }}>
              {loading ? <><div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"/>Connexion…</> : <>Se connecter <ChevronRight className="w-4 h-4"/></>}
            </button>
            <div className="text-center text-sm text-neutral-500 pt-2">
              Pas encore de compte ? <button className="text-[#c9a961] font-medium hover:underline">Essai gratuit 14 jours</button>
            </div>
          </div>

          <div className="mt-10 pt-6 border-t border-neutral-200 text-xs text-neutral-400 text-center">
            Démo : <code className="px-1.5 py-0.5 bg-neutral-100 rounded text-neutral-600">mohamed@darelhout.tn</code> / <code className="px-1.5 py-0.5 bg-neutral-100 rounded text-neutral-600">demo2026</code>
          </div>
        </div>
      </div>
    </div>
  );
};

// ============ SIDEBAR ============
const Sidebar = ({ current, setCurrent, onLogout, open, setOpen }) => {
  const items = [
    { id: 'dashboard', icon: LayoutDashboard, label: 'Tableau de bord' },
    { id: 'pos', icon: ShoppingCart, label: 'Point de vente' },
    { id: 'stock', icon: Package, label: 'Stock' },
    { id: 'recipes', icon: ChefHat, label: 'Fiches techniques' },
    { id: 'reports', icon: BarChart3, label: 'Rapports' },
    { id: 'users', icon: Users, label: 'Personnel' },
    { id: 'settings', icon: Settings, label: 'Paramètres' },
  ];

  return (
    <>
      {open && <div className="lg:hidden fixed inset-0 bg-black/50 z-30" onClick={()=>setOpen(false)}/>}
      <aside className={`fixed lg:sticky top-0 left-0 h-screen w-64 bg-neutral-950 text-white flex flex-col z-40 transition-transform ${open ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
        <div className="p-6 border-b border-neutral-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: 'linear-gradient(135deg, #d4a574 0%, #c9a961 100%)' }}>
              <ChefHat className="w-5 h-5 text-neutral-950" strokeWidth={2.5}/>
            </div>
            <div className="min-w-0">
              <div className="font-serif text-lg leading-tight">RestoGest</div>
              <div className="text-[10px] text-neutral-500 tracking-[0.2em] uppercase">Dar El Hout</div>
            </div>
          </div>
        </div>

        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          <div className="text-[10px] text-neutral-600 tracking-[0.2em] uppercase px-3 py-2">Modules</div>
          {items.map(item => {
            const Icon = item.icon;
            const active = current === item.id;
            return (
              <button key={item.id} onClick={()=>{setCurrent(item.id); setOpen(false);}}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all ${active ? 'bg-white text-neutral-950 font-medium shadow-lg' : 'text-neutral-400 hover:text-white hover:bg-white/5'}`}>
                <Icon className="w-4 h-4 flex-shrink-0" strokeWidth={active?2.5:2}/>
                <span className="flex-1 text-left">{item.label}</span>
                {active && <ChevronRight className="w-3.5 h-3.5"/>}
              </button>
            );
          })}
        </nav>

        {/* Upgrade card */}
        <div className="p-3">
          <div className="rounded-xl p-4 relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #d4a574 0%, #8b6f3d 100%)' }}>
            <div className="absolute -right-6 -top-6 opacity-20"><Crown className="w-20 h-20"/></div>
            <div className="relative">
              <div className="text-[10px] uppercase tracking-[0.2em] opacity-80 mb-1">Plan Pro</div>
              <div className="font-serif text-lg leading-tight mb-2">Passez à Premium</div>
              <div className="text-xs opacity-80 mb-3">Multi-restos + IA analytics</div>
              <button className="bg-neutral-950 text-white text-xs px-3 py-1.5 rounded-md hover:bg-neutral-800 transition font-medium">Découvrir</button>
            </div>
          </div>
        </div>

        <div className="p-3 border-t border-neutral-800">
          <button onClick={onLogout} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-neutral-400 hover:text-white hover:bg-white/5">
            <LogOut className="w-4 h-4"/> Déconnexion
          </button>
        </div>
      </aside>
    </>
  );
};

// ============ TOPBAR ============
const Topbar = ({ title, subtitle, onMenu }) => (
  <div className="flex items-center justify-between px-4 sm:px-8 py-5 border-b border-neutral-200 bg-white/80 backdrop-blur-xl sticky top-0 z-20">
    <div className="flex items-center gap-4 min-w-0">
      <button onClick={onMenu} className="lg:hidden p-2 -ml-2 text-neutral-600"><Menu className="w-5 h-5"/></button>
      <div className="min-w-0">
        {subtitle && <div className="text-xs tracking-[0.2em] uppercase text-[#c9a961] mb-0.5 truncate">{subtitle}</div>}
        <h1 className="font-serif text-2xl sm:text-3xl truncate">{title}</h1>
      </div>
    </div>
    <div className="flex items-center gap-2 sm:gap-3">
      <button className="hidden sm:flex items-center gap-2 px-3 py-2 border border-neutral-200 rounded-lg text-sm text-neutral-600 hover:border-neutral-300">
        <Search className="w-4 h-4"/> <span className="hidden md:inline">Recherche…</span>
      </button>
      <button className="p-2 border border-neutral-200 rounded-lg text-neutral-600 hover:border-neutral-300 relative">
        <Bell className="w-4 h-4"/>
        <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#d4a574] text-white text-[10px] rounded-full flex items-center justify-center font-bold">3</span>
      </button>
      <div className="flex items-center gap-3 pl-2 sm:pl-3 border-l border-neutral-200">
        <div className="w-9 h-9 rounded-full flex items-center justify-center text-white text-sm font-medium" style={{ background: 'linear-gradient(135deg, #d4a574 0%, #8b6f3d 100%)' }}>MB</div>
        <div className="hidden sm:block">
          <div className="text-sm font-medium leading-tight">Mohamed B.</div>
          <div className="text-xs text-neutral-500">Admin</div>
        </div>
      </div>
    </div>
  </div>
);

// ============ DASHBOARD ============
const Dashboard = ({ stock, recipes, orders }) => {
  const todayCA = SALES_HISTORY[SALES_HISTORY.length-1].ca;
  const yesterdayCA = SALES_HISTORY[SALES_HISTORY.length-2].ca;
  const caDelta = ((todayCA - yesterdayCA) / yesterdayCA * 100);

  const totalCA = SALES_HISTORY.reduce((s,d)=>s+d.ca, 0);
  const totalOrders = SALES_HISTORY.reduce((s,d)=>s+d.orders, 0);
  const avgTicket = totalCA / totalOrders;
  const avgFoodCost = SALES_HISTORY.reduce((s,d)=>s+d.foodCost, 0) / totalCA * 100;

  const lowStock = stock.filter(s => s.quantity <= s.minStock);

  const categoryData = [
    { name: 'Plats principaux', value: 58, color: '#d4a574' },
    { name: 'Entrées', value: 22, color: '#8b6f3d' },
    { name: 'Boissons', value: 15, color: '#c9a961' },
    { name: 'Desserts', value: 5, color: '#e8d4a8' },
  ];

  return (
    <div className="p-4 sm:p-8 space-y-6">
      {/* Hero KPI */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard label="Chiffre d'affaires (aujourd'hui)" value={formatTND(todayCA)} delta={caDelta} icon={DollarSign} accent/>
        <KPICard label="Commandes (aujourd'hui)" value={formatNum(SALES_HISTORY[SALES_HISTORY.length-1].orders)} delta={8.4} icon={ShoppingCart}/>
        <KPICard label="Panier moyen (14j)" value={formatTND(avgTicket)} delta={3.2} icon={Target}/>
        <KPICard label="Food cost moyen" value={avgFoodCost.toFixed(1)+'%'} delta={-2.1} icon={Percent} inverse/>
      </div>

      {/* Graphique CA + Camembert */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-white rounded-xl border border-neutral-200 p-6">
          <div className="flex items-start justify-between mb-6">
            <div>
              <div className="text-xs tracking-[0.2em] uppercase text-[#c9a961] mb-1">Performance</div>
              <h3 className="font-serif text-xl">Évolution du chiffre d'affaires</h3>
              <div className="text-sm text-neutral-500 mt-1">14 derniers jours · {formatTND(totalCA)}</div>
            </div>
            <div className="flex gap-2">
              {['7j','14j','30j'].map((p,i)=>(
                <button key={p} className={`px-3 py-1.5 text-xs rounded-md ${i===1?'bg-neutral-900 text-white':'bg-neutral-100 text-neutral-600'}`}>{p}</button>
              ))}
            </div>
          </div>
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={SALES_HISTORY}>
              <defs>
                <linearGradient id="caGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#d4a574" stopOpacity={0.4}/>
                  <stop offset="100%" stopColor="#d4a574" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f5f5f5" vertical={false}/>
              <XAxis dataKey="dayShort" axisLine={false} tickLine={false} tick={{fontSize: 11, fill: '#a3a3a3'}}/>
              <YAxis axisLine={false} tickLine={false} tick={{fontSize: 11, fill: '#a3a3a3'}} tickFormatter={v=>v+' TND'}/>
              <Tooltip contentStyle={{background:'#0a0a0a', border:'none', borderRadius:8, color:'white'}} labelStyle={{color:'#d4a574'}} formatter={(v)=>formatTND(v)}/>
              <Area type="monotone" dataKey="ca" stroke="#d4a574" strokeWidth={2.5} fill="url(#caGrad)"/>
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-xl border border-neutral-200 p-6">
          <div className="text-xs tracking-[0.2em] uppercase text-[#c9a961] mb-1">Répartition</div>
          <h3 className="font-serif text-xl mb-6">Ventes par catégorie</h3>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={categoryData} cx="50%" cy="50%" innerRadius={55} outerRadius={85} paddingAngle={2} dataKey="value">
                {categoryData.map((e,i) => <Cell key={i} fill={e.color}/>)}
              </Pie>
              <Tooltip contentStyle={{background:'#0a0a0a', border:'none', borderRadius:8, color:'white'}}/>
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-2.5 mt-4">
            {categoryData.map(c => (
              <div key={c.name} className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2"><div className="w-2.5 h-2.5 rounded-full" style={{background:c.color}}/><span className="text-neutral-700">{c.name}</span></div>
                <span className="font-medium">{c.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Top produits + Alertes IA */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-white rounded-xl border border-neutral-200 p-6">
          <div className="flex items-center justify-between mb-5">
            <div>
              <div className="text-xs tracking-[0.2em] uppercase text-[#c9a961] mb-1">Best-sellers</div>
              <h3 className="font-serif text-xl">Top produits vendus</h3>
            </div>
            <Award className="w-5 h-5 text-[#d4a574]"/>
          </div>
          <div className="space-y-3">
            {TOP_PRODUCTS.map((p,i) => (
              <div key={p.name} className="flex items-center gap-4 p-3 rounded-lg hover:bg-neutral-50 transition">
                <div className="w-8 h-8 flex items-center justify-center rounded-md bg-neutral-100 text-neutral-600 font-serif font-medium text-sm">{i+1}</div>
                <div className="flex-1 min-w-0">
                  <div className="font-medium truncate">{p.name}</div>
                  <div className="text-xs text-neutral-500">{p.sold} vendus · {formatTND(p.revenue)}</div>
                </div>
                <div className={`flex items-center gap-1 text-xs font-medium ${p.trend>0?'text-green-600':'text-red-500'}`}>
                  {p.trend>0?<ArrowUpRight className="w-3 h-3"/>:<ArrowDownRight className="w-3 h-3"/>}
                  {Math.abs(p.trend)}%
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Alertes intelligentes */}
        <div className="rounded-xl border border-neutral-200 overflow-hidden" style={{ background: 'linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%)' }}>
          <div className="p-6 text-white">
            <div className="flex items-center gap-2 mb-5">
              <div className="w-8 h-8 rounded-md flex items-center justify-center" style={{background:'#d4a574'}}><Sparkles className="w-4 h-4 text-neutral-950"/></div>
              <div>
                <div className="text-[10px] tracking-[0.2em] uppercase text-[#d4a574]">IA Analytics</div>
                <h3 className="font-serif text-xl">Recommandations intelligentes</h3>
              </div>
            </div>
            <div className="space-y-3">
              {lowStock.length > 0 && (
                <AlertItem icon={AlertTriangle} color="#ef4444" title={`${lowStock.length} article(s) en rupture imminente`} text={`${lowStock[0].name} et ${lowStock.length-1} autres sous seuil critique`}/>
              )}
              <AlertItem icon={TrendingDown} color="#f59e0b" title="Food cost élevé sur Lablebi" text="42% vs 30% cible. Renégocier avec Sidi Daoud ?"/>
              <AlertItem icon={Sparkles} color="#d4a574" title="Opportunité : augmenter prix Thé menthe" text="Marge actuelle 82%, demande +22%. Test à 3.5 TND recommandé"/>
              <AlertItem icon={Flame} color="#10b981" title="Pic ventes prévu ce weekend" text="+34% attendu. Renforcer stock agneau & semoule"/>
            </div>
          </div>
        </div>
      </div>

      {/* Food cost vs Ventes */}
      <div className="bg-white rounded-xl border border-neutral-200 p-6">
        <div className="flex items-start justify-between mb-5">
          <div>
            <div className="text-xs tracking-[0.2em] uppercase text-[#c9a961] mb-1">Rentabilité</div>
            <h3 className="font-serif text-xl">Food cost vs Ventes</h3>
            <div className="text-sm text-neutral-500 mt-1">Cible : 30% · Actuel : {avgFoodCost.toFixed(1)}%</div>
          </div>
        </div>
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={SALES_HISTORY}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f5f5f5" vertical={false}/>
            <XAxis dataKey="dayShort" axisLine={false} tickLine={false} tick={{fontSize: 11, fill: '#a3a3a3'}}/>
            <YAxis axisLine={false} tickLine={false} tick={{fontSize: 11, fill: '#a3a3a3'}}/>
            <Tooltip contentStyle={{background:'#0a0a0a', border:'none', borderRadius:8, color:'white'}} formatter={(v)=>formatTND(v)}/>
            <Legend wrapperStyle={{fontSize:12}}/>
            <Bar dataKey="ca" fill="#0a0a0a" name="Ventes" radius={[4,4,0,0]}/>
            <Bar dataKey="foodCost" fill="#d4a574" name="Food cost" radius={[4,4,0,0]}/>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

const KPICard = ({ label, value, delta, icon: Icon, accent, inverse }) => {
  const positive = inverse ? delta < 0 : delta > 0;
  return (
    <div className={`rounded-xl p-5 border transition-all hover:shadow-lg ${accent ? 'text-white border-transparent' : 'bg-white border-neutral-200'}`}
      style={accent ? { background: 'linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%)' } : {}}>
      <div className="flex items-start justify-between mb-3">
        <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${accent ? 'bg-[#d4a574]/20 text-[#d4a574]' : 'bg-neutral-100 text-neutral-600'}`}>
          <Icon className="w-4 h-4"/>
        </div>
        <div className={`flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-md ${positive ? (accent?'bg-green-500/20 text-green-400':'bg-green-50 text-green-700') : (accent?'bg-red-500/20 text-red-400':'bg-red-50 text-red-700')}`}>
          {delta > 0 ? <ArrowUpRight className="w-3 h-3"/> : <ArrowDownRight className="w-3 h-3"/>}
          {Math.abs(delta).toFixed(1)}%
        </div>
      </div>
      <div className={`text-xs mb-1 ${accent ? 'text-neutral-400' : 'text-neutral-500'}`}>{label}</div>
      <div className="font-serif text-2xl sm:text-3xl tracking-tight">{value}</div>
    </div>
  );
};

const AlertItem = ({ icon: Icon, color, title, text }) => (
  <div className="flex items-start gap-3 p-3 rounded-lg bg-white/5 border border-white/10 hover:bg-white/10 transition cursor-pointer">
    <div className="w-8 h-8 rounded-md flex items-center justify-center flex-shrink-0" style={{background: `${color}20`}}>
      <Icon className="w-4 h-4" style={{color}}/>
    </div>
    <div className="flex-1 min-w-0">
      <div className="text-sm font-medium leading-tight">{title}</div>
      <div className="text-xs text-neutral-400 mt-0.5">{text}</div>
    </div>
    <ChevronRight className="w-4 h-4 text-neutral-500 flex-shrink-0"/>
  </div>
);

// ============ POS ============
const POS = ({ recipes, stock, onValidateOrder }) => {
  const [cart, setCart] = useState([]);
  const [activeCategory, setActiveCategory] = useState('Tous');
  const [search, setSearch] = useState('');
  const [paymentModal, setPaymentModal] = useState(false);

  const categories = ['Tous', ...new Set(recipes.map(r=>r.category))];
  const filtered = recipes.filter(r =>
    (activeCategory==='Tous' || r.category===activeCategory) &&
    r.name.toLowerCase().includes(search.toLowerCase())
  );

  const addToCart = (recipe) => {
    setCart(prev => {
      const existing = prev.find(i => i.id === recipe.id);
      if (existing) return prev.map(i => i.id === recipe.id ? {...i, qty: i.qty+1} : i);
      return [...prev, { ...recipe, qty: 1 }];
    });
  };

  const updateQty = (id, delta) => {
    setCart(prev => prev.map(i => i.id===id ? {...i, qty: Math.max(0, i.qty+delta)} : i).filter(i=>i.qty>0));
  };

  const subtotal = cart.reduce((s,i) => s + i.sellPrice * i.qty, 0);
  const tva = subtotal * 0.19;
  const total = subtotal + tva;

  return (
    <div className="flex flex-col lg:flex-row h-[calc(100vh-5rem)] bg-neutral-50">
      {/* Produits */}
      <div className="flex-1 p-4 sm:p-6 overflow-y-auto">
        <div className="mb-5 flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 text-neutral-400"/>
            <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Rechercher un plat…"
              className="w-full bg-white border border-neutral-200 rounded-lg py-3 pl-11 pr-4 focus:border-[#c9a961] focus:ring-2 focus:ring-[#c9a961]/20 outline-none"/>
          </div>
        </div>

        <div className="flex gap-2 mb-5 overflow-x-auto pb-2">
          {categories.map(c => (
            <button key={c} onClick={()=>setActiveCategory(c)}
              className={`px-4 py-2 rounded-lg text-sm whitespace-nowrap transition ${activeCategory===c ? 'bg-neutral-900 text-white' : 'bg-white border border-neutral-200 text-neutral-600 hover:border-neutral-300'}`}>
              {c}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {filtered.map(r => {
            const cost = calculateRecipeCost(r, stock);
            const margin = ((r.sellPrice - cost) / r.sellPrice * 100);
            return (
              <button key={r.id} onClick={()=>addToCart(r)}
                className="bg-white rounded-xl border border-neutral-200 p-4 text-left hover:border-[#d4a574] hover:shadow-lg transition-all group">
                <div className="text-4xl mb-3">{r.image}</div>
                <div className="font-medium text-sm leading-tight mb-1">{r.name}</div>
                <div className="text-xs text-neutral-500 mb-3">{r.category}</div>
                <div className="flex items-end justify-between">
                  <div className="font-serif text-lg">{r.sellPrice.toFixed(2)} <span className="text-xs text-neutral-500">TND</span></div>
                  <div className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${margin>60?'bg-green-50 text-green-700':margin>40?'bg-amber-50 text-amber-700':'bg-red-50 text-red-700'}`}>
                    M. {margin.toFixed(0)}%
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Panier */}
      <div className="w-full lg:w-96 bg-white border-t lg:border-t-0 lg:border-l border-neutral-200 flex flex-col">
        <div className="p-5 border-b border-neutral-200">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-xs tracking-[0.2em] uppercase text-[#c9a961] mb-1">Commande</div>
              <div className="font-serif text-xl">Table #{Math.floor(Math.random()*20)+1}</div>
            </div>
            <button onClick={()=>setCart([])} className="text-xs text-neutral-500 hover:text-red-500">Vider</button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4">
          {cart.length === 0 ? (
            <div className="text-center py-12 text-neutral-400">
              <ShoppingCart className="w-10 h-10 mx-auto mb-3 opacity-40"/>
              <div className="text-sm">Panier vide</div>
              <div className="text-xs mt-1">Cliquez sur un plat pour l'ajouter</div>
            </div>
          ) : (
            <div className="space-y-2">
              {cart.map(item => (
                <div key={item.id} className="flex items-center gap-3 p-3 rounded-lg bg-neutral-50 border border-neutral-200">
                  <div className="text-2xl">{item.image}</div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate">{item.name}</div>
                    <div className="text-xs text-neutral-500">{item.sellPrice.toFixed(2)} TND</div>
                  </div>
                  <div className="flex items-center gap-1 bg-white border border-neutral-200 rounded-md">
                    <button onClick={()=>updateQty(item.id,-1)} className="w-7 h-7 flex items-center justify-center hover:bg-neutral-100 rounded-l-md"><Minus className="w-3 h-3"/></button>
                    <div className="w-7 text-center text-sm font-medium">{item.qty}</div>
                    <button onClick={()=>updateQty(item.id,1)} className="w-7 h-7 flex items-center justify-center hover:bg-neutral-100 rounded-r-md"><Plus className="w-3 h-3"/></button>
                  </div>
                  <div className="text-sm font-medium w-16 text-right">{(item.sellPrice*item.qty).toFixed(2)}</div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="p-5 border-t border-neutral-200 space-y-3 bg-neutral-50">
          <div className="space-y-1.5 text-sm">
            <div className="flex justify-between text-neutral-600"><span>Sous-total</span><span>{formatTND(subtotal)}</span></div>
            <div className="flex justify-between text-neutral-600"><span>TVA (19%)</span><span>{formatTND(tva)}</span></div>
            <div className="flex justify-between font-serif text-xl pt-2 border-t border-neutral-200"><span>Total</span><span>{formatTND(total)}</span></div>
          </div>
          <button disabled={cart.length===0} onClick={()=>setPaymentModal(true)}
            className="w-full py-3.5 rounded-lg font-medium text-white disabled:opacity-40 disabled:cursor-not-allowed transition"
            style={{ background: cart.length ? 'linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%)' : '#a3a3a3' }}>
            Valider la commande →
          </button>
          <div className="grid grid-cols-2 gap-2">
            <button className="py-2 text-xs text-neutral-600 border border-neutral-200 rounded-lg hover:bg-white flex items-center justify-center gap-1.5"><Printer className="w-3.5 h-3.5"/> Ticket</button>
            <button className="py-2 text-xs text-neutral-600 border border-neutral-200 rounded-lg hover:bg-white flex items-center justify-center gap-1.5"><Clock className="w-3.5 h-3.5"/> Mettre en attente</button>
          </div>
        </div>
      </div>

      {/* Modal paiement */}
      {paymentModal && (
        <PaymentModal total={total} onClose={()=>setPaymentModal(false)} onComplete={()=>{onValidateOrder(cart); setCart([]); setPaymentModal(false);}}/>
      )}
    </div>
  );
};

const PaymentModal = ({ total, onClose, onComplete }) => {
  const [method, setMethod] = useState('cash');
  const [done, setDone] = useState(false);
  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-md overflow-hidden shadow-2xl">
        {done ? (
          <div className="p-10 text-center">
            <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
              <Check className="w-8 h-8 text-green-600" strokeWidth={3}/>
            </div>
            <h3 className="font-serif text-2xl mb-2">Paiement confirmé</h3>
            <p className="text-neutral-500 mb-6">Montant encaissé : {formatTND(total)}</p>
            <button onClick={onComplete} className="w-full py-3 rounded-lg bg-neutral-900 text-white font-medium">Nouvelle commande</button>
          </div>
        ) : (
          <>
            <div className="p-6 border-b border-neutral-200">
              <div className="flex items-center justify-between">
                <h3 className="font-serif text-2xl">Paiement</h3>
                <button onClick={onClose} className="w-8 h-8 rounded-full hover:bg-neutral-100 flex items-center justify-center"><X className="w-4 h-4"/></button>
              </div>
              <div className="mt-4 text-center p-6 bg-neutral-50 rounded-lg">
                <div className="text-xs uppercase tracking-wider text-neutral-500 mb-1">Montant total</div>
                <div className="font-serif text-4xl">{formatTND(total)}</div>
              </div>
            </div>
            <div className="p-6 space-y-3">
              <div className="text-xs tracking-[0.2em] uppercase text-neutral-500 mb-2">Mode de paiement</div>
              <div className="grid grid-cols-3 gap-2">
                {[
                  {id:'cash', icon: Banknote, label:'Espèces'},
                  {id:'card', icon: CreditCard, label:'Carte'},
                  {id:'mix', icon: Zap, label:'Mixte'},
                ].map(m => {
                  const Icon = m.icon;
                  return (
                    <button key={m.id} onClick={()=>setMethod(m.id)}
                      className={`p-4 rounded-lg border-2 transition ${method===m.id ? 'border-[#d4a574] bg-[#d4a574]/5' : 'border-neutral-200 hover:border-neutral-300'}`}>
                      <Icon className={`w-5 h-5 mx-auto mb-2 ${method===m.id?'text-[#d4a574]':'text-neutral-600'}`}/>
                      <div className="text-xs font-medium">{m.label}</div>
                    </button>
                  );
                })}
              </div>
              <button onClick={()=>setDone(true)} className="w-full py-3.5 mt-4 rounded-lg text-white font-medium" style={{ background: 'linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%)' }}>
                Confirmer le paiement
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

// ============ STOCK ============
const StockManager = ({ stock, setStock }) => {
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');

  const filtered = stock.filter(s => {
    const matchSearch = s.name.toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === 'all' || (filter === 'low' && s.quantity <= s.minStock) || (filter === 'ok' && s.quantity > s.minStock);
    return matchSearch && matchFilter;
  });

  const totalValue = stock.reduce((s,i) => s + i.quantity * i.pricePerUnit, 0);
  const lowCount = stock.filter(s => s.quantity <= s.minStock).length;

  return (
    <div className="p-4 sm:p-8 space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white rounded-xl border border-neutral-200 p-5">
          <div className="text-xs text-neutral-500 mb-1">Valeur totale du stock</div>
          <div className="font-serif text-2xl">{formatTND(totalValue)}</div>
          <div className="text-xs text-neutral-400 mt-1">{stock.length} références</div>
        </div>
        <div className="bg-white rounded-xl border border-neutral-200 p-5">
          <div className="text-xs text-neutral-500 mb-1">Alertes stock faible</div>
          <div className="font-serif text-2xl text-red-600">{lowCount}</div>
          <div className="text-xs text-neutral-400 mt-1">À réapprovisionner</div>
        </div>
        <div className="bg-white rounded-xl border border-neutral-200 p-5">
          <div className="text-xs text-neutral-500 mb-1">Dernière mise à jour</div>
          <div className="font-serif text-2xl">Aujourd'hui</div>
          <div className="text-xs text-neutral-400 mt-1">16 avril 2026 · 09:15</div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-neutral-200 overflow-hidden">
        <div className="p-5 border-b border-neutral-200 flex flex-col sm:flex-row gap-3 justify-between">
          <div className="flex gap-2 flex-1">
            <div className="relative flex-1 max-w-sm">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400"/>
              <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Rechercher une matière…"
                className="w-full bg-neutral-50 border border-neutral-200 rounded-lg py-2.5 pl-10 pr-4 text-sm focus:border-[#c9a961] outline-none"/>
            </div>
            <select value={filter} onChange={e=>setFilter(e.target.value)} className="px-3 py-2.5 bg-neutral-50 border border-neutral-200 rounded-lg text-sm">
              <option value="all">Tous</option>
              <option value="low">Stock faible</option>
              <option value="ok">Stock OK</option>
            </select>
          </div>
          <div className="flex gap-2">
            <button className="px-3 py-2.5 text-sm border border-neutral-200 rounded-lg hover:bg-neutral-50 flex items-center gap-2"><Upload className="w-4 h-4"/> Importer</button>
            <button className="px-3 py-2.5 text-sm border border-neutral-200 rounded-lg hover:bg-neutral-50 flex items-center gap-2"><FileSpreadsheet className="w-4 h-4"/> Export XLSX</button>
            <button className="px-3 py-2.5 text-sm text-white rounded-lg flex items-center gap-2" style={{background:'#0a0a0a'}}><Plus className="w-4 h-4"/> Ajouter</button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-neutral-50 text-xs uppercase tracking-wider text-neutral-500">
              <tr>
                <th className="text-left px-5 py-3 font-medium">Matière première</th>
                <th className="text-left px-5 py-3 font-medium">Stock actuel</th>
                <th className="text-left px-5 py-3 font-medium">Seuil mini</th>
                <th className="text-left px-5 py-3 font-medium">Prix unitaire</th>
                <th className="text-left px-5 py-3 font-medium">Valeur</th>
                <th className="text-left px-5 py-3 font-medium">Fournisseur</th>
                <th className="text-left px-5 py-3 font-medium">Statut</th>
                <th className="px-5 py-3"></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(s => {
                const low = s.quantity <= s.minStock;
                const critical = s.quantity <= s.minStock * 0.5;
                return (
                  <tr key={s.id} className="border-t border-neutral-100 hover:bg-neutral-50 transition">
                    <td className="px-5 py-4 font-medium">{s.name}</td>
                    <td className="px-5 py-4">{s.quantity} <span className="text-xs text-neutral-500">{s.unit}</span></td>
                    <td className="px-5 py-4 text-neutral-500">{s.minStock} {s.unit}</td>
                    <td className="px-5 py-4">{s.pricePerUnit.toFixed(2)} TND</td>
                    <td className="px-5 py-4 font-medium">{(s.quantity*s.pricePerUnit).toFixed(2)} TND</td>
                    <td className="px-5 py-4 text-neutral-600">{s.supplier}</td>
                    <td className="px-5 py-4">
                      <span className={`inline-flex items-center gap-1.5 px-2 py-1 rounded-md text-xs font-medium ${critical?'bg-red-50 text-red-700':low?'bg-amber-50 text-amber-700':'bg-green-50 text-green-700'}`}>
                        <div className={`w-1.5 h-1.5 rounded-full ${critical?'bg-red-500':low?'bg-amber-500':'bg-green-500'}`}/>
                        {critical?'Critique':low?'Faible':'OK'}
                      </span>
                    </td>
                    <td className="px-5 py-4"><button className="text-neutral-400 hover:text-neutral-700"><MoreVertical className="w-4 h-4"/></button></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

// ============ FICHES TECHNIQUES ============
const Recipes = ({ recipes, stock }) => {
  const [selected, setSelected] = useState(recipes[0]);

  return (
    <div className="p-4 sm:p-8">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Liste */}
        <div className="lg:col-span-1 space-y-3">
          <div className="flex items-center justify-between mb-3">
            <div className="text-xs tracking-[0.2em] uppercase text-neutral-500">Recettes · {recipes.length}</div>
            <button className="text-xs text-[#c9a961] hover:underline flex items-center gap-1"><Plus className="w-3 h-3"/> Nouvelle</button>
          </div>
          {recipes.map(r => {
            const cost = calculateRecipeCost(r, stock);
            const margin = ((r.sellPrice - cost) / r.sellPrice * 100);
            const active = selected?.id === r.id;
            return (
              <button key={r.id} onClick={()=>setSelected(r)}
                className={`w-full text-left p-4 rounded-xl border transition-all ${active ? 'bg-neutral-900 text-white border-neutral-900' : 'bg-white border-neutral-200 hover:border-neutral-300'}`}>
                <div className="flex items-center gap-3">
                  <div className="text-2xl">{r.image}</div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-sm truncate">{r.name}</div>
                    <div className={`text-xs ${active?'text-neutral-400':'text-neutral-500'}`}>{r.category}</div>
                  </div>
                  <div className={`text-xs font-medium ${margin>60?'text-green-500':margin>40?'text-amber-500':'text-red-500'}`}>{margin.toFixed(0)}%</div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Détail */}
        {selected && <RecipeDetail recipe={selected} stock={stock}/>}
      </div>
    </div>
  );
};

const RecipeDetail = ({ recipe, stock }) => {
  const cost = calculateRecipeCost(recipe, stock);
  const margin = recipe.sellPrice - cost;
  const marginPct = (margin / recipe.sellPrice * 100);
  const suggestedPrice = cost * 3.2; // Cible food cost 31%
  const foodCostPct = (cost / recipe.sellPrice * 100);

  return (
    <div className="lg:col-span-2 space-y-6">
      <div className="bg-white rounded-xl border border-neutral-200 overflow-hidden">
        <div className="p-6 border-b border-neutral-200" style={{ background: 'linear-gradient(135deg, #fafafa 0%, #f0ebe0 100%)' }}>
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="text-5xl">{recipe.image}</div>
              <div>
                <div className="text-xs tracking-[0.2em] uppercase text-[#c9a961] mb-1">{recipe.category}</div>
                <h2 className="font-serif text-3xl mb-1">{recipe.name}</h2>
                <div className="text-sm text-neutral-500">Fiche technique · #{recipe.id.toString().padStart(4,'0')}</div>
              </div>
            </div>
            <div className="flex gap-2">
              <button className="p-2.5 border border-neutral-200 bg-white rounded-lg hover:border-neutral-300"><Edit2 className="w-4 h-4"/></button>
              <button className="p-2.5 border border-neutral-200 bg-white rounded-lg hover:border-red-300 hover:text-red-600"><Trash2 className="w-4 h-4"/></button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 divide-x divide-y lg:divide-y-0 divide-neutral-200">
          <div className="p-5">
            <div className="text-xs uppercase tracking-wider text-neutral-500 mb-1">Coût matière</div>
            <div className="font-serif text-xl">{formatTND(cost)}</div>
          </div>
          <div className="p-5">
            <div className="text-xs uppercase tracking-wider text-neutral-500 mb-1">Prix de vente</div>
            <div className="font-serif text-xl">{formatTND(recipe.sellPrice)}</div>
          </div>
          <div className="p-5">
            <div className="text-xs uppercase tracking-wider text-neutral-500 mb-1">Marge</div>
            <div className={`font-serif text-xl ${marginPct>60?'text-green-600':marginPct>40?'text-amber-600':'text-red-600'}`}>{marginPct.toFixed(1)}%</div>
          </div>
          <div className="p-5">
            <div className="text-xs uppercase tracking-wider text-neutral-500 mb-1">Food cost</div>
            <div className={`font-serif text-xl ${foodCostPct<30?'text-green-600':foodCostPct<40?'text-amber-600':'text-red-600'}`}>{foodCostPct.toFixed(1)}%</div>
          </div>
        </div>
      </div>

      {/* Ingrédients */}
      <div className="bg-white rounded-xl border border-neutral-200 p-6">
        <h3 className="font-serif text-xl mb-5">Composition</h3>
        <div className="space-y-2">
          {recipe.ingredients.map((ing, i) => {
            const item = stock.find(s => s.id === ing.stockId);
            if (!item) return null;
            const itemCost = item.pricePerUnit * ing.quantity;
            const pct = (itemCost / cost * 100);
            return (
              <div key={i} className="flex items-center gap-4 p-3 rounded-lg hover:bg-neutral-50">
                <div className="w-8 h-8 rounded-md bg-[#d4a574]/10 flex items-center justify-center text-[#8b6f3d] font-serif text-sm">{i+1}</div>
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm">{item.name}</div>
                  <div className="text-xs text-neutral-500">{ing.quantity} {item.unit} × {item.pricePerUnit.toFixed(2)} TND/{item.unit}</div>
                </div>
                <div className="hidden sm:block w-32">
                  <div className="h-1.5 bg-neutral-100 rounded-full overflow-hidden">
                    <div className="h-full rounded-full" style={{ width: `${pct}%`, background: 'linear-gradient(90deg, #d4a574 0%, #8b6f3d 100%)' }}/>
                  </div>
                  <div className="text-[10px] text-neutral-500 mt-0.5">{pct.toFixed(0)}% du coût</div>
                </div>
                <div className="text-sm font-medium w-20 text-right">{formatTND(itemCost)}</div>
              </div>
            );
          })}
        </div>

        {/* Suggestion IA */}
        <div className="mt-6 p-4 rounded-lg border-2 border-dashed" style={{ borderColor: '#d4a574', background: '#d4a574/5' }}>
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-md flex items-center justify-center flex-shrink-0" style={{background:'#d4a574'}}>
              <Sparkles className="w-4 h-4 text-white"/>
            </div>
            <div className="flex-1">
              <div className="text-xs tracking-[0.2em] uppercase text-[#8b6f3d] mb-1">Suggestion IA</div>
              <div className="text-sm text-neutral-700">
                Prix de vente optimal suggéré : <strong>{formatTND(suggestedPrice)}</strong> pour un food cost cible de 31%.
                {foodCostPct > 35 && <span className="text-red-600"> Food cost actuel trop élevé — négocier avec fournisseurs ou ajuster portion.</span>}
                {foodCostPct < 25 && <span className="text-green-600"> Excellente rentabilité — produit à mettre en avant !</span>}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// ============ RAPPORTS ============
const Reports = () => {
  const [period, setPeriod] = useState('14j');

  const foodCostByProduct = [
    { name: 'Couscous Agneau', actual: 32, target: 30 },
    { name: 'Poulet Rôti', actual: 28, target: 30 },
    { name: 'Brik à l\'œuf', actual: 25, target: 30 },
    { name: 'Lablebi', actual: 42, target: 30 },
    { name: 'Thé menthe', actual: 18, target: 30 },
    { name: 'Salade', actual: 33, target: 30 },
  ];

  const lossAnalysis = [
    { category: 'Déchets cuisine', value: 185, pct: 35 },
    { category: 'Sur-portionnement', value: 142, pct: 27 },
    { category: 'Erreurs POS', value: 68, pct: 13 },
    { category: 'Vols/casses', value: 95, pct: 18 },
    { category: 'Autres', value: 38, pct: 7 },
  ];

  return (
    <div className="p-4 sm:p-8 space-y-6">
      {/* Filtres */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex gap-2 flex-wrap">
          {['7j','14j','30j','90j','Personnalisé'].map(p => (
            <button key={p} onClick={()=>setPeriod(p)}
              className={`px-4 py-2 rounded-lg text-sm ${period===p ? 'bg-neutral-900 text-white':'bg-white border border-neutral-200 text-neutral-600'}`}>{p}</button>
          ))}
        </div>
        <div className="flex gap-2">
          <button className="px-3 py-2 text-sm border border-neutral-200 rounded-lg hover:bg-neutral-50 flex items-center gap-2"><FileSpreadsheet className="w-4 h-4"/> Exporter Excel</button>
          <button className="px-3 py-2 text-sm border border-neutral-200 rounded-lg hover:bg-neutral-50 flex items-center gap-2"><Download className="w-4 h-4"/> PDF</button>
        </div>
      </div>

      {/* Food cost par produit */}
      <div className="bg-white rounded-xl border border-neutral-200 p-6">
        <div className="mb-5">
          <div className="text-xs tracking-[0.2em] uppercase text-[#c9a961] mb-1">Analyse rentabilité</div>
          <h3 className="font-serif text-xl">Food cost par produit (vs cible 30%)</h3>
        </div>
        <ResponsiveContainer width="100%" height={280}>
          <BarChart data={foodCostByProduct} layout="vertical" margin={{left:20}}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f5f5f5" horizontal={false}/>
            <XAxis type="number" axisLine={false} tickLine={false} tick={{fontSize: 11, fill: '#a3a3a3'}} tickFormatter={v=>v+'%'}/>
            <YAxis type="category" dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 11, fill: '#525252'}} width={120}/>
            <Tooltip contentStyle={{background:'#0a0a0a', border:'none', borderRadius:8, color:'white'}}/>
            <Bar dataKey="actual" name="Food cost réel" radius={[0,4,4,0]}>
              {foodCostByProduct.map((e,i)=>(
                <Cell key={i} fill={e.actual>e.target?'#ef4444':e.actual>25?'#d4a574':'#10b981'}/>
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Ventes vs conso + pertes */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-neutral-200 p-6">
          <div className="mb-5">
            <div className="text-xs tracking-[0.2em] uppercase text-[#c9a961] mb-1">Comparaison</div>
            <h3 className="font-serif text-xl">Ventes vs Consommation réelle</h3>
          </div>
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={SALES_HISTORY}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f5f5f5"/>
              <XAxis dataKey="dayShort" axisLine={false} tickLine={false} tick={{fontSize: 11, fill: '#a3a3a3'}}/>
              <YAxis axisLine={false} tickLine={false} tick={{fontSize: 11, fill: '#a3a3a3'}}/>
              <Tooltip contentStyle={{background:'#0a0a0a', border:'none', borderRadius:8, color:'white'}}/>
              <Legend wrapperStyle={{fontSize:12}}/>
              <Line type="monotone" dataKey="ca" stroke="#0a0a0a" strokeWidth={2} name="Ventes" dot={false}/>
              <Line type="monotone" dataKey="foodCost" stroke="#d4a574" strokeWidth={2} name="Coût matière" dot={false}/>
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-xl border border-neutral-200 p-6">
          <div className="mb-5 flex items-start justify-between">
            <div>
              <div className="text-xs tracking-[0.2em] uppercase text-[#c9a961] mb-1">Détection anomalies</div>
              <h3 className="font-serif text-xl">Analyse des pertes</h3>
              <div className="text-sm text-neutral-500 mt-1">528 TND identifiés sur 14j</div>
            </div>
            <AlertCircle className="w-5 h-5 text-red-500"/>
          </div>
          <div className="space-y-3">
            {lossAnalysis.map(l => (
              <div key={l.category}>
                <div className="flex items-center justify-between text-sm mb-1">
                  <span className="text-neutral-700">{l.category}</span>
                  <div className="flex items-center gap-3"><span className="text-neutral-500 text-xs">{l.pct}%</span><span className="font-medium">{l.value} TND</span></div>
                </div>
                <div className="h-1.5 bg-neutral-100 rounded-full overflow-hidden">
                  <div className="h-full rounded-full" style={{ width: `${l.pct*2.8}%`, background: 'linear-gradient(90deg, #ef4444 0%, #d4a574 100%)' }}/>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recommandations */}
      <div className="rounded-xl overflow-hidden" style={{ background: 'linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%)' }}>
        <div className="p-6 text-white">
          <div className="flex items-center gap-2 mb-5">
            <Sparkles className="w-5 h-5 text-[#d4a574]"/>
            <div>
              <div className="text-[10px] tracking-[0.2em] uppercase text-[#d4a574]">Conseiller IA</div>
              <h3 className="font-serif text-xl">Recommandations d'optimisation</h3>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <RecCard color="#ef4444" title="Lablebi : food cost 42%" detail="Réduire portion de 10% ou augmenter prix à 9.5 TND. Gain estimé : +380 TND/mois"/>
            <RecCard color="#d4a574" title="Achats groupés" detail="Regrouper commandes Marché Central (-8% volume). Économie : ~120 TND/mois"/>
            <RecCard color="#10b981" title="Promouvoir Thé menthe" detail="Marge 82% et demande en hausse. Mise en avant menu = +500 TND/mois potentiels"/>
          </div>
        </div>
      </div>
    </div>
  );
};

const RecCard = ({ color, title, detail }) => (
  <div className="p-4 rounded-lg bg-white/5 border border-white/10 hover:bg-white/10 transition">
    <div className="w-1 h-8 rounded-full mb-3" style={{background: color}}/>
    <div className="font-medium text-sm mb-1">{title}</div>
    <div className="text-xs text-neutral-400 leading-relaxed">{detail}</div>
  </div>
);

// ============ PERSONNEL ============
const UsersManager = () => {
  const roles = {
    Admin: { color: '#d4a574', perms: ['Tous droits'] },
    Manager: { color: '#8b6f3d', perms: ['Ventes', 'Stock', 'Rapports'] },
    Caissier: { color: '#525252', perms: ['POS', 'Caisse'] },
    Serveur: { color: '#a3a3a3', perms: ['POS limité'] },
  };

  return (
    <div className="p-4 sm:p-8 space-y-6">
      <div className="flex flex-col sm:flex-row justify-between gap-3">
        <div className="text-sm text-neutral-500">{USERS.length} utilisateurs · {USERS.filter(u=>u.status==='actif').length} actifs</div>
        <button className="px-4 py-2 text-sm text-white rounded-lg flex items-center gap-2 self-start" style={{background:'#0a0a0a'}}><Plus className="w-4 h-4"/> Ajouter un utilisateur</button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {USERS.map(u => {
          const role = roles[u.role] || roles.Serveur;
          return (
            <div key={u.id} className="bg-white rounded-xl border border-neutral-200 p-5 hover:shadow-lg transition">
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 rounded-full flex items-center justify-center text-white font-medium" style={{background: `linear-gradient(135deg, ${role.color} 0%, ${role.color}cc 100%)`}}>
                  {u.name.split(' ').map(n=>n[0]).join('')}
                </div>
                <span className={`text-[10px] uppercase tracking-wider px-2 py-1 rounded-md font-medium ${u.status==='actif'?'bg-green-50 text-green-700':'bg-neutral-100 text-neutral-500'}`}>
                  {u.status}
                </span>
              </div>
              <div className="font-medium">{u.name}</div>
              <div className="text-xs text-neutral-500 mb-3">{u.email}</div>
              <div className="flex items-center gap-2 mb-3">
                <div className="text-[10px] uppercase tracking-wider px-2 py-1 rounded" style={{background: `${role.color}15`, color: role.color}}>{u.role}</div>
              </div>
              <div className="text-xs text-neutral-500 border-t border-neutral-100 pt-3 mt-3">
                Dernière connexion : {u.lastLogin}
              </div>
            </div>
          );
        })}
      </div>

      {/* Journal d'activité */}
      <div className="bg-white rounded-xl border border-neutral-200 p-6">
        <h3 className="font-serif text-xl mb-5">Historique des actions</h3>
        <div className="space-y-2">
          {[
            {user:'Karim Jebali', action:'Validé commande #2847', time:'Il y a 5 min', type:'pos'},
            {user:'Mohamed Ben Ali', action:'Modifié prix Couscous Agneau', time:'Il y a 22 min', type:'edit'},
            {user:'Sonia Trabelsi', action:'Import stock depuis XLSX (45 lignes)', time:'Il y a 1h', type:'import'},
            {user:'Leila Mansouri', action:'Connexion', time:'Il y a 2h', type:'auth'},
            {user:'Karim Jebali', action:'Annulé commande #2842', time:'Il y a 3h', type:'cancel'},
          ].map((log, i) => (
            <div key={i} className="flex items-center gap-4 p-3 rounded-lg hover:bg-neutral-50 transition">
              <div className={`w-2 h-2 rounded-full ${log.type==='cancel'?'bg-red-500':log.type==='edit'?'bg-amber-500':'bg-green-500'}`}/>
              <div className="flex-1 min-w-0">
                <div className="text-sm"><span className="font-medium">{log.user}</span> <span className="text-neutral-500">· {log.action}</span></div>
              </div>
              <div className="text-xs text-neutral-400">{log.time}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// ============ PARAMÈTRES ============
const SettingsPage = () => {
  const [currentPlan] = useState('pro');

  const plans = [
    {
      id: 'basic', name: 'Basic', price: 49, period: 'mois',
      features: ['POS basique', 'Jusqu\'à 100 produits', 'Stock simple', 'Rapports de base', '1 utilisateur'],
      color: '#525252',
    },
    {
      id: 'pro', name: 'Pro', price: 129, period: 'mois',
      features: ['POS complet', 'Produits illimités', 'Stock avancé + fiches tech.', 'Analytics complets', 'Jusqu\'à 10 utilisateurs', 'Export Excel', 'Support prioritaire'],
      color: '#d4a574', popular: true,
    },
    {
      id: 'premium', name: 'Premium', price: 299, period: 'mois',
      features: ['Tout du plan Pro', 'Multi-restaurants', 'IA Analytics avancés', 'API & intégrations', 'Utilisateurs illimités', 'Account manager dédié', 'Formation équipe'],
      color: '#0a0a0a',
    },
  ];

  return (
    <div className="p-4 sm:p-8 space-y-8">
      {/* Infos restaurant */}
      <section>
        <div className="text-xs tracking-[0.2em] uppercase text-[#c9a961] mb-2">Informations</div>
        <h2 className="font-serif text-2xl mb-5">Restaurant</h2>
        <div className="bg-white rounded-xl border border-neutral-200 p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <SettingField label="Nom du restaurant" value="Dar El Hout"/>
            <SettingField label="Matricule fiscal" value="1234567/A/P/M/000"/>
            <SettingField label="Téléphone" value="+216 71 234 567"/>
            <SettingField label="Adresse" value="45 Av. Habib Bourguiba, Tunis"/>
            <SettingField label="Devise" value="Dinar Tunisien (TND)" readOnly/>
            <SettingField label="TVA par défaut" value="19%"/>
          </div>
        </div>
      </section>

      {/* Abonnement */}
      <section>
        <div className="flex items-center justify-between mb-5">
          <div>
            <div className="text-xs tracking-[0.2em] uppercase text-[#c9a961] mb-2">Monétisation</div>
            <h2 className="font-serif text-2xl">Plan & abonnement</h2>
          </div>
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#d4a574]/10 text-[#8b6f3d] text-sm font-medium">
            <Crown className="w-4 h-4"/> Plan actuel : Pro
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {plans.map(p => {
            const active = p.id === currentPlan;
            return (
              <div key={p.id} className={`relative rounded-xl p-6 transition ${active ? 'bg-neutral-900 text-white' : 'bg-white border border-neutral-200'}`}>
                {p.popular && <div className="absolute -top-3 left-1/2 -translate-x-1/2 text-[10px] uppercase tracking-wider bg-[#d4a574] text-neutral-950 px-3 py-1 rounded-full font-bold">Populaire</div>}
                <div className="flex items-center gap-2 mb-3">
                  {p.id==='premium' && <Crown className="w-4 h-4 text-[#d4a574]"/>}
                  {p.id==='pro' && <Star className="w-4 h-4 text-[#d4a574]"/>}
                  <div className="font-serif text-xl">{p.name}</div>
                </div>
                <div className="mb-5">
                  <span className="font-serif text-4xl">{p.price}</span>
                  <span className={`text-sm ${active?'text-neutral-400':'text-neutral-500'}`}> TND / {p.period}</span>
                </div>
                <ul className="space-y-2 mb-6">
                  {p.features.map(f => (
                    <li key={f} className="flex items-start gap-2 text-sm">
                      <Check className={`w-4 h-4 flex-shrink-0 mt-0.5 ${active?'text-[#d4a574]':'text-green-600'}`}/>
                      <span className={active?'text-neutral-300':'text-neutral-600'}>{f}</span>
                    </li>
                  ))}
                </ul>
                <button className={`w-full py-2.5 rounded-lg text-sm font-medium transition ${active ? 'bg-white/10 text-white cursor-not-allowed' : p.id==='premium' ? 'bg-[#d4a574] text-neutral-950 hover:bg-[#c9a961]' : 'bg-neutral-900 text-white hover:bg-neutral-800'}`} disabled={active}>
                  {active ? 'Plan actif' : p.id==='premium' ? 'Passer à Premium' : 'Choisir ce plan'}
                </button>
              </div>
            );
          })}
        </div>
      </section>

      {/* Mobile & Intégrations */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-neutral-200 p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{background:'#d4a574'}}><Smartphone className="w-5 h-5 text-neutral-950"/></div>
            <div>
              <h3 className="font-serif text-lg">Application mobile</h3>
              <div className="text-xs text-neutral-500">Android APK · Mode offline</div>
            </div>
          </div>
          <p className="text-sm text-neutral-600 mb-4">
            Téléchargez l'APK Android pour utiliser RestoGest sur tablette ou mobile en salle. Synchronisation automatique avec le cloud dès reconnexion.
          </p>
          <div className="flex gap-2">
            <button className="flex-1 py-2.5 rounded-lg text-white text-sm font-medium flex items-center justify-center gap-2" style={{background:'#0a0a0a'}}><Download className="w-4 h-4"/> Télécharger APK</button>
            <button className="px-4 py-2.5 border border-neutral-200 rounded-lg text-sm hover:bg-neutral-50">QR Code</button>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-neutral-200 p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-lg flex items-center justify-center bg-green-100 text-green-700"><FileSpreadsheet className="w-5 h-5"/></div>
            <div>
              <h3 className="font-serif text-lg">Intégration Excel</h3>
              <div className="text-xs text-neutral-500">Import & Export XLSX</div>
            </div>
          </div>
          <p className="text-sm text-neutral-600 mb-4">
            Importez vos produits et stock depuis un fichier Excel. Exportez automatiquement vos ventes et rapports au format XLSX.
          </p>
          <div className="flex gap-2">
            <button className="flex-1 py-2.5 border border-neutral-200 rounded-lg text-sm hover:bg-neutral-50 flex items-center justify-center gap-2"><Upload className="w-4 h-4"/> Importer</button>
            <button className="flex-1 py-2.5 border border-neutral-200 rounded-lg text-sm hover:bg-neutral-50 flex items-center justify-center gap-2"><Download className="w-4 h-4"/> Exporter</button>
          </div>
        </div>
      </div>
    </div>
  );
};

const SettingField = ({ label, value, readOnly }) => (
  <div>
    <label className="block text-xs uppercase tracking-wider text-neutral-500 mb-1.5">{label}</label>
    <input defaultValue={value} readOnly={readOnly}
      className={`w-full border border-neutral-200 rounded-lg py-2.5 px-3.5 text-sm focus:border-[#c9a961] outline-none ${readOnly?'bg-neutral-50 text-neutral-500':'bg-white'}`}/>
  </div>
);

// ============ APP PRINCIPALE ============
export default function App() {
  const [logged, setLogged] = useState(false);
  const [view, setView] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [stock, setStock] = useState(INITIAL_STOCK);
  const [orders, setOrders] = useState([]);

  const titles = {
    dashboard: { title: 'Tableau de bord', subtitle: 'Jeudi 16 avril 2026' },
    pos: { title: 'Point de vente', subtitle: 'Caisse en ligne' },
    stock: { title: 'Gestion du stock', subtitle: 'Matières premières' },
    recipes: { title: 'Fiches techniques', subtitle: 'Recettes & coûts' },
    reports: { title: 'Rapports & analytics', subtitle: 'Intelligence métier' },
    users: { title: 'Personnel', subtitle: 'Équipe & permissions' },
    settings: { title: 'Paramètres', subtitle: 'Configuration' },
  };

  if (!logged) return <LoginScreen onLogin={()=>setLogged(true)}/>;

  return (
    <div className="min-h-screen bg-neutral-50" style={{ fontFamily: "'Manrope', system-ui, sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;1,400&family=Manrope:wght@300;400;500;600;700&display=swap');
        html, body, #root { font-family: 'Manrope', system-ui, sans-serif; }
        .font-serif { font-family: 'Playfair Display', Georgia, serif !important; }
        * { -webkit-font-smoothing: antialiased; }
      `}</style>

      <div className="flex">
        <Sidebar current={view} setCurrent={setView} onLogout={()=>setLogged(false)} open={sidebarOpen} setOpen={setSidebarOpen}/>
        <div className="flex-1 min-w-0">
          <Topbar title={titles[view].title} subtitle={titles[view].subtitle} onMenu={()=>setSidebarOpen(true)}/>
          {view === 'dashboard' && <Dashboard stock={stock} recipes={INITIAL_RECIPES} orders={orders}/>}
          {view === 'pos' && <POS recipes={INITIAL_RECIPES} stock={stock} onValidateOrder={(c)=>setOrders(p=>[...p,c])}/>}
          {view === 'stock' && <StockManager stock={stock} setStock={setStock}/>}
          {view === 'recipes' && <Recipes recipes={INITIAL_RECIPES} stock={stock}/>}
          {view === 'reports' && <Reports/>}
          {view === 'users' && <UsersManager/>}
          {view === 'settings' && <SettingsPage/>}
        </div>
      </div>
    </div>
  );
}
